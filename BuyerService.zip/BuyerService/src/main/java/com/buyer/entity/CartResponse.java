package com.buyer.entity;

public class CartResponse {
	
	
	private Integer cartItemId;
	private Integer itemId;
	private Integer quantity;
	
	public CartResponse() {
		
	}

	public CartResponse(Integer cartId, Integer itemId, Integer quantity) {
		super();
		this.cartItemId = cartId;
		this.itemId = itemId;
		this.quantity = quantity;
	}

	public Integer getCartId() {
		return cartItemId;
	}

	public void setCartId(Integer cartId) {
		this.cartItemId = cartId;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "CartResponse [cartId=" +cartItemId + ", itemId=" + itemId + ", quantity=" + quantity + "]";
	}
	
	

}
