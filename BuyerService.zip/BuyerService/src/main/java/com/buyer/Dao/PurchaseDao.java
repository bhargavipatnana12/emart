package com.buyer.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.buyer.entity.PurchaseHistory;

public interface PurchaseDao extends JpaRepository<PurchaseHistory, Integer>{

}
