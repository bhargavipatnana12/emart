package com.buyer.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.buyer.entity.TransactionHistory;

public interface TransactionDao extends JpaRepository<TransactionHistory, Integer>{

}
