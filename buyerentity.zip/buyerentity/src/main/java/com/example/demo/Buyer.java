package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="buyer")
public class Buyer {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer BuyerId;
	@Column(name="Buyer_Name")
	private String BuyerName;
	
	public Buyer(Integer buyerId, String buyerName, String password, String email) {
		super();
		this.BuyerId = buyerId;
		this.BuyerName = buyerName;
		this.Password = password;
		this.Email = email;
	}
	private String Password;
	private String Email;
	public String getBuyerName() {
		return BuyerName;
	}
	public void setBuyerName(String buyerName) {
		BuyerName = buyerName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	@Override
	public String toString() {
		return "Buyer [BuyerId=" + BuyerId + ", BuyerName=" + BuyerName + ", Password=" + Password + ", Email=" + Email
				+ "]";
	}
	
	
}
