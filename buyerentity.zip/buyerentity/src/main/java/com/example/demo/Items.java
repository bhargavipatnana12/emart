package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/*id
category_id
subcategory_id
price
item_name
description
stock_number
remarks*/
@Entity
@Table(name="items")

public class Items {
	@Id
	private int id;
	@Column(name="category_id")
	
	private Category category_id;
	
	@ManyToOne
	@JoinColumn(name="subcategory_id")
	
	private SubCategory subcategory_id;
	@Column(name="price")
	private Float price;
	@Column(name="item_name")
	private String item_name;
	@Column(name="description")
	private String description;
	@Column(name="stock_number")
	private String stock_number;
	@Column(name="remarks")
	private String remarks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStock_number() {
		return stock_number;
	}
	public void setStock_number(String stock_number) {
		this.stock_number = stock_number;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Items(int id, int category_id, int subcategory_id, Float price, String item_name, String description,
			String stock_number, String remarks) {
		super();
		this.id = id;
		
		this.price = price;
		this.item_name = item_name;
		this.description = description;
		this.stock_number = stock_number;
		this.remarks = remarks;
	}
	public Items() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Items [id=" + id +",   price="
				+ price + ", item_name=" + item_name + ", description=" + description + ", stock_number=" + stock_number
				+ ", remarks=" + remarks + "]";
	}
	
}
