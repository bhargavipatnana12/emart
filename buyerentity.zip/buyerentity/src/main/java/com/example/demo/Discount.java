package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="discount")

public class Discount {
	@Id
	private int id;
	@Column(name="Discount_code")
	private float Discount_code;
	@Column(name="percentage")
	private float percentage;
	@Column(name="start_date")
	private String start_date;
	@Column(name="end_date")
	private String end_date;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getDiscount_code() {
		return Discount_code;
	}
	public void setDiscount_code(float discount_code) {
		Discount_code = discount_code;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public Discount() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Discount [id=" + id + ", Discount_code=" + Discount_code + ", percentage=" + percentage
				+ ", start_date=" + start_date + ", end_date=" + end_date + "]";
	}
	public Discount(int id, float discount_code, float percentage, String start_date, String end_date) {
		super();
		this.id = id;
		Discount_code = discount_code;
		this.percentage = percentage;
		this.start_date = start_date;
		this.end_date = end_date;
	}
	
}
