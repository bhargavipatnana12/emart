package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="subCategory")

public class SubCategory {
	//subcategory_id
	//subcategory_name
	//category_id
//	brief_details
	//GST %
	@Id
	private int subcategory_id;
	@Column(name="subcategory_name")
	private float subcategory_name;
	@ManyToOne
	@JoinColumn(name="category_id")
	@Column(name="category_id")
	private Category category_id;
	
	@Column(name="brief_details")
	private String brief_details;
	@Column(name="gst")
	private Float gst;
	public int getSubcategory_id() {
		return subcategory_id;
	}
	public void setSubcategory_id(int subcategory_id) {
		this.subcategory_id = subcategory_id;
	}
	public float getSubcategory_name() {
		return subcategory_name;
	}
	public void setSubcategory_name(float subcategory_name) {
		this.subcategory_name = subcategory_name;
	}
	
	
	public String getBrief_details() {
		return brief_details;
	}
	public void setBrief_details(String brief_details) {
		this.brief_details = brief_details;
	}
	public Float getGst() {
		return gst;
	}
	public void setGst(Float gst) {
		this.gst = gst;
	}
	
	
	
	public SubCategory(int subcategory_id, float subcategory_name,  String brief_details,
			Float gst) {
		super();
		this.subcategory_id = subcategory_id;
		this.subcategory_name = subcategory_name;
		
		this.brief_details = brief_details;
		this.gst = gst;
	}
	public SubCategory() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "SubCategory [subcategory_id=" + subcategory_id + ", subcategory_name=" + subcategory_name
				 + ", brief_details=" + brief_details + ", gst=" + gst + "]";
	}
	
}
