package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="transactions")
public class Transactions {

	
	@Id
	private int id;
	@Column(name="user_id")
	private int user_id;
	@Column(name="seller_id")
	private int sellere_id;
	@Column(name="transaction_type")
	private String transaction_type;
	@Column(name="date_time")
	private String date_time;
	@Column(name="remarks")
	private String remarks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getSellere_id() {
		return sellere_id;
	}
	public void setSellere_id(int sellere_id) {
		this.sellere_id = sellere_id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public String getDate_time() {
		return date_time;
	}
	public void setDate_time(String date_time) {
		this.date_time = date_time;
	}
	
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Transactions(int id, int user_id, int sellere_id, String transaction_type, String date_time,
			String remarks) {
		super();
		this.id = id;
		this.user_id = user_id;
		this.sellere_id = sellere_id;
		this.transaction_type = transaction_type;
		this.date_time = date_time;
		this.remarks = remarks;
	}@Override
	public String toString() {
		return "Transactions [id=" + id + ", user_id=" + user_id + ", sellere_id=" + sellere_id + ", transaction_type="
				+ transaction_type + ", date_time=" + date_time + ", remarks=" + remarks + "]";
	}
	public Transactions() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
