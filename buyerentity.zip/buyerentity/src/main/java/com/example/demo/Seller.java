package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seller")
public class Seller {
/*id 
	username
	password
	companyname
	GSTIN
	brief about company
	postal_address
	website
	emailid
	contact number*/
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	@Column(name="username")
	
	private String category_name;
	@Column(name="brief_details")
	private String brief_details;
}
